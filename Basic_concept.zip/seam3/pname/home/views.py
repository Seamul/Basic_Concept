from django.shortcuts import render,HttpResponse,get_object_or_404
from .models import Post,Comment
from django.core.paginator import Paginator,EmptyPage,PageNotAnInteger
from .forms import EmailPistForms,CommentForm
from django.core.mail  import send_mail
def index(request):
    object_list=Post.objects.all()
    paginator=Paginator(object_list,3)
    page=request.GET.get('page')
    page = request.GET.get('page')
    
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer deliver the first page
        posts = paginator.page(1)
    except EmptyPage:
        # If page is out of range deliver last page of results
        posts = paginator.page(paginator.num_pages)
    return render(request,
                  'index.html',
                  {'page': page,
                   'posts': posts})

def detail(request,year,month,day,post):

	return HttpResponse('<h1>SEAM</h1>')
def  post_share(request):
	sent=False
	if request.method=='POST':
		form=EmailPistForms(request.POST)
		if form.is_valid():
			cd=form.cleaned_data
			send_mail('test',cd['commants'],'islamseamul26@gmail.com',[cd['email']])
			sent=True
	else:
		form=EmailPistForms()
	return render(request,'share.html',{'form':form,'sent':sent})

def  post_detail(request,year,month,day,post):
	post=get_object_or_404(Post,publish__day=day,publish__month=month,publish__year=year,slug=post)
	comments=post.comments.filter(active=True)
	if request.method=="POST":
		comment_form=CommentForm(request.POST)
		if comment_form.is_valid():
			new_comment=comment_form.save(commit=False)
			new_comment.post=post
			new_comment.save()

	else:
		comment_form=CommentForm()
	return render(request,'detail.html',{'comment_form':comment_form,'comments':comments,'post':post})